ies = []
ies.append({ "iei" : "50", "value" : "PDU session status", "type" : "PDU session status", "reference" : "9.10.3.40", "presence" : "O", "format" : "TLV", "length" : "4-34"})
msg_list[key]["ies"] = ies
