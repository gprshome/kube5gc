ies = []
ies.append({ "iei" : "", "value" : "Access type", "type" : "Access type", "reference" : "9.10.3.10", "presence" : "M", "format" : "V", "length" : "1/2"})
msg_list[key]["ies"] = ies
