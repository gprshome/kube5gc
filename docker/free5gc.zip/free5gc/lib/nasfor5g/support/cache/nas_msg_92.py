ies = []
ies.append({ "iei" : "", "value" : "Mobile identity", "type" : "5GS mobile identity", "reference" : "9.10.3.4", "presence" : "M", "format" : "LV", "length" : "2-TBD"})
msg_list[key]["ies"] = ies
