ies = []
ies.append({ "iei" : "", "value" : "Identity type", "type" : "5GS identity type", "reference" : "9.10.3.3", "presence" : "M", "format" : "V", "length" : "1/2"})
msg_list[key]["ies"] = ies
