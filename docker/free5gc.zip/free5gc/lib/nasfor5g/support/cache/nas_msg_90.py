ies = []
ies.append({ "iei" : "", "value" : "ngKSI", "type" : "key set identifier", "reference" : "9.10.3.29", "presence" : "M", "format" : "V", "length" : "1/2"})
ies.append({ "iei" : "", "value" : "EAP message", "type" : "EAP message", "reference" : "9.10.2.2", "presence" : "M", "format" : "LV-E", "length" : "6-1502"})
msg_list[key]["ies"] = ies
