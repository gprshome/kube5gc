ies = []
ies.append({ "iei" : "", "value" : "5GMM cause", "type" : "5GMM cause", "reference" : "9.10.3.2", "presence" : "M", "format" : "V", "length" : "1"})
msg_list[key]["ies"] = ies
