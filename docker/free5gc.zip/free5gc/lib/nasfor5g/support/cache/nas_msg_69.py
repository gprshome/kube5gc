ies = []
ies.append({ "iei" : "", "value" : "De-registration type", "type" : "De-registration type", "reference" : "9.10.3.18", "presence" : "M", "format" : "V", "length" : "1/2"})
ies.append({ "iei" : "", "value" : "5GS mobile identity", "type" : "5GS mobile identity", "reference" : "9.10.3.4", "presence" : "M", "format" : "TLV", "length" : "TBD"})
msg_list[key]["ies"] = ies
