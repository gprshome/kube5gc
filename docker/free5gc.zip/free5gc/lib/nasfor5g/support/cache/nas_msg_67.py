ies = []
ies.append({ "iei" : "TBD", "value" : "Transparent container", "type" : "Transparent container", "reference" : "9.10.3.49", "presence" : "O", "format" : "TBD", "length" : "TBD"})
msg_list[key]["ies"] = ies
