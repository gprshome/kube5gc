ies = []
ies.append({ "ie_type" : "Recovery Time Stamp", "ie_value" : "Recovery Time Stamp", "presence" : "M", "instance" : "0", "comment" : "This IE shall contain the time stamp when the node was started see clause 19A of 3GPPTS23.007[24]."})
msg_list[key]["ies"] = ies
