This content was contributed by Krishnan Srinivasan from Allot Communication.

The dictionary entries may need some adjustments to 
match the content of the dict_dcca_3gpp extension.

Thank you Krishnan!
